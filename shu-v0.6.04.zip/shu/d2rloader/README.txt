# D2RLoader files

This folder holds the D2RLoader files used by this mod.

* metadata.json stores basic mod information and the D2RLoader version it was made for.
* `config/d2rloader.toml` lets this mod override some D2RLoader settings while it is active.
* `plugins/` can contain D2RLoader plugin DLLs used only by this mod.
* `patches/` can contain memory patch files.
* `logs/` stores log files created by mod plugins.
* Use the MPQ viewer to browse D2RLoader reference data in `d2rloader.mpq`. This file is in the game folder, beside `D2RLoader.exe` and `D2RCore.dll`. Copy only the resources you want to override into your mod's `.mpq` folder.
* Some plugins also include an MPQ, such as `d2rl-charm-inv.mpq`. Browse it with the MPQ viewer and copy only the resources you want to override into your mod's `.mpq` folder.
* Add an empty `data/global/.DISABLE_DEBUG` file to disable D2RLoader debug tools while the mod is active. Useful for packed `.mpq` mods where the marker cannot be removed as a loose file.

Keep this folder next to the mod’s `.mpq` folder when sharing the mod.

Loading the mod adds missing settings and their help text to `config/d2rloader.toml` as disabled examples. Existing values and comments stay unchanged. Remove the `#` before a setting to enable it.

Run `d2rl update` to restore any missing D2RLoader files and add missing settings examples. Other existing files stay unchanged.

This README can be safely deleted.
