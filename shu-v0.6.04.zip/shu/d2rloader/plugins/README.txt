D2RLoader mod plugins

Put this mod's plugin DLL files in this folder.
D2RLoader loads them while this mod is active.

Learn more: https://d2rloader.net
Build plugins: https://github.com/D2RLoader/PluginSDK
